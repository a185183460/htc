package com.batian.btspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtSpringBootApplication.class, args);
	}
}
